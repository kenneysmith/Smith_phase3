<?php

$servername="localhost";
$username="root";
$password="";
$dbname="myDb";
$conn="";
$conn= new mysqli($servername,$username,$password,$dbname);
if($conn){
   
    echo "connected ";
}
else{
    echo "You are not connected";

}
?>
<!DOCTYPE html>
<html lang="en">
<head>

   <title>EMPLOYEE DATABASE MANAGEMENT SYSTEM</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to external CSS -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: yellow;
            margin: 0;
            padding: 20px;
        }
        h1, h2 {
            color: #333;
        }
        
        input[type="text"],
        input[type="email"],
        input[type="number"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px 15px;
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #4cae4c;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: #fff;
        }
        th, td {
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        a {
            color: #d9534f;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h1>EMPLOYEE DATABASE MANAGEMENT SYSTEM</h1>

    <form action="register.php" method="POST">
    <div class="form-group">
        <label for="NAME">NAME:</label>
        <input type="NAME" id="NAME" name="NAME" class="form-control" required>
    </div>
</form>

<form action="your_action_page.php" method="POST">
    <div class="form-group">
        <label for="G.MAIL">G.MAIL:</label>
        <input type="G.MAIL" id="G.MAIL" name="G.MAIL" class="form-control" required>
    </div>
        
</form>

<form action="your_action_page.php" method="POST">
    <div class="form-group">
        <label for="SALARY">SALARY:</label>
        <input type="SALARY" id="SALARY" name="SALARY" class="form-control" required>
    </div><br>
    


        <form action="your_action_page.php" method="POST">
    <div class="form-group">
        <label for="ADDRESS">ADDRESS:</label>
        <input type="ADDRESS" id="ADDRESS" name="ADDRESS" class="form-control" required>
    </div>
    
</form>
<form action="your_action_page.php" method="POST">
    <div class="form-group">
        <label for="DEPARTMENT">DEPARTMENT:</label>
        <input type="DEPARTMENT" id="DEPARTMENT" name="DEPARTMENT" class="form-control" required>
    </div><br>
    



        <form action="your_action_page.php" method="POST">
    <div class="form-group">
        <label for="PASSWORD">PASSWORD:</label>
        <input type="PASSWORD" id="PASSWORD" name="PASSWORD" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
    </form>

   
               





                
</body>
</html>